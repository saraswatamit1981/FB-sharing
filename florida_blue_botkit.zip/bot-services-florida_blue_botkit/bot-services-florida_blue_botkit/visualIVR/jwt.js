var config = require("./config.json");

var jwt = require('jsonwebtoken');
var bodyparser = require('body-parser');
var express = require("express");
var app = express();
var port = config.server.port;
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({
    extended: false
}));

function jwtToken(visitorId,ttk) {
    var identity = "sampleIdentity@kore.com"; //req.body.identity;
    var clientId = config.credentials.appId; //req.body.clientId;
    var clientSecret = config.credentials.apikey // config.credentials.apikey//req.body.clientSecret;
    var isAnonymous = false
    var aud = "https://idproxy.kore.com/authorize";
    var fName = "";
    var lName = "";

    var options = {
         "iat": Date.now()/1000,
        "exp": Date.now()/1000+300 ,
        "jti": "1234",
        "aud": aud, //Non Mandatory
        "iss": clientId,
        "sub": identity,
        "isAnonymous": isAnonymous,
        "ivrUserId": visitorId,
        "ttk": ttk
        }
  
    
    var headers = {};
    if (fName || lName) {
        headers.header = {
            "fName": fName,
            "lName": lName
        }
    }
  var token = jwt.sign(options, clientSecret, headers );
  console.log("----------token-------", token);
    return token;
}
module.exports = jwtToken;