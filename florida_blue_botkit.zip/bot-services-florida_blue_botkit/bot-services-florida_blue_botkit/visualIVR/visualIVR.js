var config = require("./config.json");
var botId = Object.keys(config.credentials);
var botName = "Visual IVR";
var sdk = require("./lib/sdk");
var redis = require("redis");
var redisClient = redis.createClient();
var ObjectTypes = require("./lib/sdk/ObjectTypes");
var jwtToken = require("./jwt.js");
var Promise = require("bluebird");
var api = require('./SalesforceLiveChatAPI.js');
var _ = require('lodash');
var config = require('./config.json');
var sfdc_config_file = require("./config.json").sfdc_config_file;
var sfdc_config = require(sfdc_config_file);
var debug = require('debug')("Agent");
var schedular = require('node-schedule');
var rp = require('request-promise');
var _map = {}; //used to store secure session ids //TODO: need to find clear map var
var userDataMap = {}; //this will be use to store the data object for each user
var userResponseDataMap = {};
var historyIgnoreMessages = ["INITIAL DIALOG", "#session_closed"];
var slashProc = require('./SlashProc.js').getInstance();
function guidGenerate() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
  
  
//used to generate the OTK
"use strict";
exports.__esModule = true;
var otplib_1 = require("otplib");
var secret = otplib_1.authenticator.generateSecret();
var otp = otplib_1.authenticator.generate(secret); 
try {
    var isValid = otplib_1.authenticator.check(otp, secret);
}
catch (err) {
    console.error(err);
}
//code to updateRedisWithData
var sub = require("./lib/RedisClient.js").createClient(config.redis);
var pub = require("./lib/RedisClient.js").createClient(config.redis);
pub.config("SET", "notify-keyspace-events", "KExA");

function updateRedisWithData(uuid, data) {
    pub.set(uuid, JSON.stringify(data));
    pub.set(uuid + ":data", JSON.stringify(data));
    pub.expire(uuid, 45);
    sub.subscribe("__keyspace@0__:" + uuid);
}
function storeJwtInRedis(uuid, data) {
    pub.set(uuid, data);
    pub.set(uuid , data);
    sub.subscribe("__keyspace@0__:" + uuid);
}
sub.on('message', function (channel, msg) {
    try {
        if (msg == "expired") {
            var id = channel.split(":")[1];
            pub.get(id + ":data", function (err, reply) {
                var data = JSON.parse(reply);
                if (data.context && data.context.session && data.context.session.BotUserSession && data.context.session.BotUserSession.webuId   ) {
                    console.log("already triggered the webhook");
                } else { 
                    data.context.setToken=undefined                
                    data.toJSON = function () {
                        return {
                            __payloadClass : 'OnHookPayload',
                            requestId : data.requestId,
                            botId : data.botId,
                            componentId : data.componentId,
                            componentName : data.componentName,
                            sendUserMessageUrl : data.sendUserMessageUrl,
                            sendBotMessageUrl : data.sendBotMessageUrl,
                            skipUserMessageUrl : data.skipUserMessageUrl,
                            skipBotMessageUrl : data.skipBotMessageUrl,
                            getBotVariableUrl:data.getBotVariableUrl,
                            callbackUrl : data.callbackUrl,
                            context : data.context,
                            channel : data.channel,
                            message : data.message,
                            contextId : data.contextId,
                            metaTags : data.metaTags,
                            messageObject : data.messageObject
                            };
                    }
                    pub.set(id + ":data", JSON.stringify(data));
                    return sdk.respondToHook(data);
                }
            });
        }
         } catch (err) {
        console.log("error in webhook", err);
    }
});



module.exports = {
    botId: botId,
    botName: botName,

    on_user_message: function(requestId, data, callback) {
        return sdk.sendBotMessage(data, callback);
     },

    on_bot_message: function(requestId, data, componentName, callback) {
        
        if (data.context.session.BotUserSession.ivr){ 
         var visitorId =data.context.session.opts.userId
          if(data.context.setToken && data.context.setToken==="true") 
          {
          var token = jwtToken(visitorId, otp)//pass ivr user id to create jwt
          redisClient.set(otp, token)
          var guid=guidGenerate()
          console.log("guid",guid)
          redisClient.set(guid,token)
        }
        }
         return sdk.sendUserMessage(data, callback);
 },
    on_agent_transfer: function(requestId, data, callback) {
        connectToAgent(requestId, data, callback);
    },
    on_event: function(requestId, data, callback) {
        
        return callback(null, data);
    },
    on_webhook: function(requestId, data, componentName, callback) {
        if(data.context.setToken)
        {
            data.context.setToken=undefined
        }
       try {
            var uId = data.context.session.BotUserSession.uID
            console.log("Webhook : ", requestId, componentName, uId, new Date().toISOString());
            redisClient.set(uId, JSON.stringify(data));
            if(componentName==="getLink")
            {
                
            updateRedisWithData(uId, data);
            }
            callback(null, new sdk.AsyncResponse()); //202 resp
        } catch (error) {
            console.error("Error in webhook : ", error.message);
            sdk.respondToHook(data);
        }

    },
    claimNotifier: function(req, res) {
    
        try {
            var uId = req.body.uID;
            var webuId= req.body.webuId; //
            redisClient.get(uId,  function(err, reply) { //it will delete from redis
                if (err) {
                    console.error("Error : ", err.message);
                    throw new error(err);
                }
                var reqData = JSON.parse(reply);
                if(reqData && reqData.context ) {
                reqData.context.userClicksTheLink="true"
                }
   
                var ObjectType = ObjectTypes[reqData.__payloadClass];
                
                sdk.respondToHook(new ObjectType(reqData.requestId, reqData.botId, reqData.componentId, reqData));
        
                res.sendStatus(200);
                 });
        } catch (e) {
            console.log("error in pstfn ", e.message);
            res.sendStatus(400);
        }
    },
   
};
