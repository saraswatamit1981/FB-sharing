
(function ($) {

  $(document).ready(function () {
    var fetchtoken = window.location.href;
    var storeToken = "";
    if (fetchtoken.indexOf('?p=') != -1) {
      storeToken = fetchtoken.split('?p=')[1]
    }

    function assertion(options, callback) {
     var jsonData = {
        "ttk": options.ttk
      };
      $.ajax({
        url: options.JWTUrl,
        type: 'post',
        data: jsonData,
        dataType: 'json',
        success: function (data) {
          options.assertion = data.jwt;
          options.handleError = koreBot.showError;
          options.chatHistory = koreBot.chatHistory;
          options.botDetails = koreBot.botDetails;
          callback(null, options);
          setTimeout(function () {
            if (koreBot && koreBot.initToken) {
              
              koreBot.initToken(options);
              
            }
          }, 2000);
        },
        error: function (err) {
          koreBot.showError(err.responseText);
        }
      });
      
      console.log("json data", jsonData)
    }

    var chatConfig = window.KoreSDK.chatConfig;
    chatConfig.botOptions.assertionFn = assertion;

    var koreBot = koreBotChat();
    koreBot.show(chatConfig);
    $('.openChatWindow').click(function () {
      koreBot.show(chatConfig);
    });
  });

})(jQuery || (window.KoreSDK && window.KoreSDK.dependencies && window.KoreSDK.dependencies.jQuery));
